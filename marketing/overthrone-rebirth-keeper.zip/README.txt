Seris the Rebirth Keeper: gives 1 Tensura Race Reset Scroll every 12 hours per player.

1. Copy kubejs/server_scripts/race_scroll.js to the server's kubejs/server_scripts/
2. Copy presets/rebirth_keeper.npc.nbt to config/easy_npc/preset/humanoid/
3. Restart the server (the NPC preset needs a restart; the script alone works with /reload)
4. Stand where Seris should go and run:
     /easy_npc preset import_new custom <press TAB and pick rebirth_keeper> ~ ~ ~
5. Skin: Easy NPC config -> Skin -> Custom -> add skins/rebirth_keeper.png

Players: right-click Seris -> "Claim my Race Reset Scroll".
The 12 hours are real time and are saved on the player, so logging out or restarting doesn't reset them.
Claims only work while standing next to Seris.

Staff commands:
  /racescroll check <player>   how long until they can claim again
  /racescroll reset <player>   let them claim again right now

Hologram above Seris (op): stand near her and run  /racescroll hologram
Run it again to move it, or  /racescroll hologram remove  to delete it.
