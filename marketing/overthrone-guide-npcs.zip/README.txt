OVERTHRONE guide NPCs  ([SLR] Solo Leveling Guide, [TENSURA] Tensura Guide)

1. Copy presets/*.npc.nbt to the server:  config/easy_npc/preset/humanoid/
2. Restart the server (or reload), stand where the NPC should go and run:
     /easy_npc preset import_new custom <press TAB and pick guide_slr> ~ ~ ~
     /easy_npc preset import_new custom <press TAB and pick guide_tensura> ~ ~ ~
3. Skins: open the NPC's Easy NPC config the same way you did for the other NPCs,
   go to Skin -> Custom and add skins/slr_guide.png or skins/tensura_guide.png.

Players just right-click the NPC. Every page has Back / Main Menu / Close.
