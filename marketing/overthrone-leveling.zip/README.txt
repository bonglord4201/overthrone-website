OVERTHRONE LEVELLING SYSTEM (levels 1-5000)

HOW PLAYERS LEVEL UP
  Mainly from QUESTS. Every quest now pays Level XP (shown as "Level XP" in the rewards).
    E-Rank quests 200-800 each, D 800-2,400, C 2,450-6,300, B 5,500-13,750, S 14,400-40,000.
    Finishing all 100 quests gets a player to about level 255.
  A little from killing mobs (0.3 XP per point of mob health, capped per minute so farms don't work).
  Bosses (150+ health): 1.5 XP per health point, no cap.
  Mining ores: 2-25 XP (capped per minute). Daily first login: 200 + 5 per level.
  Inside Aeonia and Netherfall all of the above is doubled.
  Vanilla XP / XP farms do NOT give levels.

INSTALL (on the server, make a backup first)
  1. kubejs/server_scripts/leveling.js            -> server kubejs/server_scripts/
  2. kubejs/server_scripts/overthrone_quests.js   -> server kubejs/server_scripts/ (replace the old one)
  3. config/ftbquests/quests/chapters/overthrone_*.snbt and config/ftbquests/quests/lang/en_us.snbt
       -> server config/ftbquests/quests/ (replace). Only these files; leave the rest of that folder alone.
  4. Restart the server.

TEST
  /level                                   your level and progress bar
  /level xp give <you> 2000                should show a LEVEL UP title
  /scoreboard objectives setdisplay sidebar ot_level     shows levels in the sidebar (run without ot_level to hide)

HUD (for the dev): scoreboard objectives ot_level, ot_xp, ot_xpneed, ot_xppct
REALMS: multiworld:aeonia and multiworld:netherfall are locked until level 300 (ops can always enter).
