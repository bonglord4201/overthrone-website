OVERTHRONE LEVELLING SYSTEM (levels 1-5000)

HOW PLAYERS LEVEL UP
  Mainly from QUESTS. Every quest now pays Level XP (shown as "Level XP" in the rewards).
    E-Rank quests 200-800 each, D 800-2,400, C 2,450-6,300, B 5,500-13,750, S 14,400-40,000.
    Finishing all 100 quests gets a player to about level 255.
  A little from killing mobs (0.3 XP per point of mob health, capped per minute so farms don't work).
  Bosses (150+ health): 1.5 XP per health point, no cap.
  Mining ores: 2-25 XP (capped per minute). Daily first login: 200 + 5 per level.
  Inside Aeonia and Netherfall all of the above is doubled.
  Vanilla XP / XP farms do NOT give levels.

INSTALL (on the server, make a backup of config/ftbquests/quests first)
  1. kubejs/server_scripts/leveling.js            -> server kubejs/server_scripts/  (new file)
  2. kubejs/server_scripts/overthrone_quests.js   -> server kubejs/server_scripts/  (replaces the old /quest board script)
  3. The 5 files in config/ftbquests/quests/chapters/ (overthrone_1_e_rank ... overthrone_5_s_rank)
       -> server config/ftbquests/quests/chapters/  (replace those 5 only)
     Nothing else in the quests folder is touched: the 10 Ledger chapters, Getting Started, the lang file,
     crate tables and player progress all stay exactly as they are. Progress is kept because quest IDs don't change.
     If you edited the E- to S-Rank chapters in-game, those edits would be lost; skip step 3 in that case.
  4. Restart the server.

TEST
  /level                                   your level and progress bar
  /level xp give <you> 2000                should show a LEVEL UP title
  /scoreboard objectives setdisplay sidebar ot_level     shows levels in the sidebar (run without ot_level to hide)

HUD (for the dev): scoreboard objectives ot_level, ot_xp, ot_xpneed, ot_xppct
REALMS: multiworld:aeonia and multiworld:netherfall are locked until level 300 (ops can always enter).
